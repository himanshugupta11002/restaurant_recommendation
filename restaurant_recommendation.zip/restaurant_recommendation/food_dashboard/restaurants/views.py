from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from restaurants.models import Restaurant

def search_restaurants(request):
    query = request.GET.get('q')
    results = []
    if query:
        results = Restaurant.objects.filter(food_item__icontains=query)
    return render(request, 'search.html', {'results': results, 'query': query})

def dashboard(request):
    return render(request, 'dashboard.html')
