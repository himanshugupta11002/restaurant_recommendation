import csv
from django.core.management.base import BaseCommand
from restaurants.models import Restaurant
import os


class Command(BaseCommand):
    help = 'Load data from CSV file'

    def handle(self, *args, **kwargs):
        # Get the directory of the current script
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        # Construct the file path relative to the project root
        file_path = os.path.join(base_dir, 'management', 'data', 'restaurants_small.csv')

        print(f'Looking for file at: {file_path}')

        if not os.path.exists(file_path):
            self.stdout.write(self.style.ERROR(f'File not found: {file_path}'))
            return

        with open(file_path, newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                Restaurant.objects.create(
                    name=row['name'],
                    location=row['location'],
                    food_item=row['items'],
                    latitude_longitude=row['lat_long'],
                    full_details=row['full_details']
                )
        self.stdout.write(self.style.SUCCESS('Data loaded successfully'))
