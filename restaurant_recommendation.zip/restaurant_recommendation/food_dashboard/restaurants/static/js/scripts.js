document.addEventListener('DOMContentLoaded', function() {
    const results = document.querySelectorAll('li');
    results.forEach(result => {
        result.addEventListener('mouseover', function() {
            result.style.backgroundColor = '#3e8e41';
        });
        result.addEventListener('mouseout', function() {
            result.style.backgroundColor = '#4CAF50';
        });
    });
});
